// @ts-check
import { defineConfig, envField } from 'astro/config'
import vercel from '@astrojs/vercel'
import mdx from '@astrojs/mdx'
import { satteri } from '@astrojs/markdown-satteri'
import { unwrapJsxParagraphs } from './lib/satteri-unwrap-jsx-paragraphs.mjs'
import { wrapTables } from './lib/satteri-wrap-tables.mjs'
import { fileURLToPath } from 'node:url'
import { copyAssets } from '../.build/copy-assets'
import { redirects } from './lib/redirects.ts'

/** @param {string} p */
const path = (p) => fileURLToPath(new URL(p, import.meta.url))

// https://astro.build/config
export default defineConfig({
  site: 'https://docs.tabler.io',
  env: {
    // DocSearch/Algolia config for the docs search (see DocsNavbar.astro).
    // Values come from the environment only (.env locally, project settings on
    // Vercel) — see .env.example. When unset, the search input is hidden.
    schema: {
      DOCSEARCH_APP_ID: envField.string({ context: 'client', access: 'public', optional: true }),
      DOCSEARCH_INDEX_NAME: envField.string({ context: 'client', access: 'public', optional: true }),
      DOCSEARCH_API_KEY: envField.string({ context: 'client', access: 'public', optional: true }),
    },
  },
  // Static output + the Vercel adapter: turns `redirects` below into real HTTP
  // redirects at Vercel's routing layer (no adapter = meta-refresh HTML pages).
  adapter: vercel(),
  // renamed/moved pages, shared with middleware.ts
  redirects,
  // pages live at the package root (./pages) — content-first layout; all
  // components/lib/data are shared (see the @shared alias). The docs content
  // itself lives in ./content and is rendered by pages/[...slug].astro.
  srcDir: '.',
  server: {
    port: 3010,
    // bind on all interfaces so the dev server is reachable from Docker
    // port mappings and other devices on the local network
    host: true,
  },
  vite: {
    define: {
      TABLER_STATIC_BASE: JSON.stringify('/static'),
    },
    resolve: {
      alias: {
        '@data': fileURLToPath(new URL('../shared/data', import.meta.url)),
        // Astro components/lib shared with preview (single source of truth)
        '@shared': fileURLToPath(new URL('../shared', import.meta.url)),
        '@ui': fileURLToPath(new URL('../shared/ui', import.meta.url)),
        // docs-only components (Example, DocsMenu, …)
        '@components': fileURLToPath(new URL('./components', import.meta.url)),
        // docs-only layouts (DocsLayout)
        '@layouts': fileURLToPath(new URL('./layouts', import.meta.url)),
        // docs-only helpers (docs collection queries)
        '@lib': fileURLToPath(new URL('./lib', import.meta.url)),
      },
    },
  },
  integrations: [
    copyAssets({
      repo: path('..'),
      publicDir: path('./public'),
      copies: [
        {
          from: path('./assets'),
          to: path('./public'),
          label: '@tabler/docs',
          requiredFile: path('./assets/favicon.ico'),
        },
        {
          // docs css built by this package's `css` and `watch:css` scripts
          // (both write here). Source is tmp-assets/
          // (not public/) because copy-assets wipes public/ on every restart —
          // anything a watcher writes straight into public/ is lost there.
          from: path('./tmp-assets/css'),
          to: path('./public/css'),
          label: '@tabler/docs',
          requiredFile: path('./tmp-assets/css/docs.css'),
        },
        {
          from: path('../core/dist'),
          to: path('./public/dist'),
          label: '@tabler/core',
          requiredFile: path('../core/dist/css/tabler.css'),
        },
        {
          // preview's demo assets, from its tmp-assets/ (not dist/ — see copy-assets.ts).
          from: path('../preview/tmp-assets'),
          to: path('./public/preview'),
          label: '@tabler/preview',
          requiredFile: path('../preview/tmp-assets/css/demo.css'),
        },
        {
          from: path('../shared/static'),
          to: path('./public/static'),
          label: 'shared assets',
          requiredFile: path('../shared/static/logo.svg'),
        },
      ],
      syncDirs: [
        { from: path('../core/dist'), to: path('./public/dist') },
        { from: path('../preview/tmp-assets'), to: path('./public/preview') },
        { from: path('./assets'), to: path('./public') },
        { from: path('./tmp-assets/css'), to: path('./public/css') },
        { from: path('../shared/static'), to: path('./public/static') },
      ],
    }),
    mdx(),
  ],
  markdown: {
    // No typographic quote rewriting.
    processor: satteri({
      features: { smartPunctuation: false },
      mdastPlugins: [unwrapJsxParagraphs],
      hastPlugins: [wrapTables],
    }),
    shikiConfig: {
      theme: 'github-dark',
    },
  },
})
