import corePackage from '@tabler/core/package.json'
import iconsInfo from '../data/icons-info.json'
import illustrationsInfo from '../data/illustrations-info.json'

const version = corePackage.version

export const site = {
  title: 'Tabler',
  version,
  docsUrl: 'https://docs.tabler.io',
  cdnUrl: `https://cdn.jsdelivr.net/npm/@tabler/core@${version}`,
  email: 'support@tabler.io',
  previewUrl: 'https://preview.tabler.io',
  githubUrl: 'https://github.com/tabler/tabler',
  githubSponsorsUrl: 'https://github.com/sponsors/codecalm',
  icons: { link: 'https://tabler.io/icons' },
  emails: { price: '$29', buy_link: 'https://r.tabler.io/buy-emails' },
  // From shared/data/icons-info.json.
  iconsCount: iconsInfo.count,
  iconsVersion: iconsInfo.version,
  // From shared/data/illustrations-info.json.
  illustrationsCount: illustrationsInfo.count,
  illustrationsVersion: illustrationsInfo.version,
  descriptionShort: 'Premium and Open Source dashboard template with responsive and high quality UI.',
  description: 'Tabler is packed with beautifully crafted components and powerful features. Jump in and start building a stunning dashboard — all for free!',
  themeColor: '#066fd1',
  cssPlugins: ['flags', 'socials', 'payments', 'vendors', 'marketing', 'themes'],
  themeColors: ['blue', 'azure', 'indigo', 'purple', 'pink', 'red', 'orange', 'yellow', 'lime', 'green', 'teal', 'cyan'],
  themeFonts: ['sans-serif', 'serif', 'monospace', 'comic'],
  themeBases: ['slate', 'gray', 'zinc', 'neutral', 'stone', 'mist'],
  themeRadiuses: ['0', '0.5', '1', '1.5', '2'],
}
